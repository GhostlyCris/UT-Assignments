package Rectangle;
import java.util.*;
public class TestRec{
    public static void main(String[] args)
    {
        Rectangle recTry1 = new Rectangle(12,6);

        System.out.println("We will try to show if the Rectangle class works.");

        System.out.println(Rectangle.getHeight() + " is the height.\n " + Rectangle.getWidth() + " is the width.");
        
    }
}