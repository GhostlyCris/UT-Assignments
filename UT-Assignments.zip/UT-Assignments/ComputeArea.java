//this program calculates CircleArea;

public class ComputeArea {
	public static void main(String [] args) {
		double radius; //declare radius;
		double area; // Declare area;
		
		// Assign value to the radius;
		radius = 15.4; // new val for radius;
		
		//Compute area;
		area = radius * radius * 3.14159;
		
		
		//Display results;
		
		System.out.println("The area for the circle of radius " + radius + " is " + area); 
		
		
	}
}
