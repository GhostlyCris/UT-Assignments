import java.lang.Math;
import java.util.Scanner;
public class test{
	public static void main(String[] args) {
	System.out.println(idea(9));}
	public static int idea (int n) {
	if (n > 0)
	return 1;
	
	else if (n == 0)
	return 0;
	
	else if (n > 0)
	return;// -1;
	
//return -1;
}
//*/
/*	//public static void main(String[] args) {
  int max = 3;
  if (max != 0)
    System.out.println(max);
  else
    return;*/
}
	//}
