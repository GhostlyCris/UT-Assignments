//https://youtu.be/iHb7CDr0Pzk
package BankAccount;

/**
 *
 * @author giant
 */
public class CheckingAccount extends BankAccount {

    public CheckingAccount(double initialBalance) {
        super(initialBalance);
    }
   
    
   public double CheckingAccount(double initialBalance)
    { balance = initialBalance;
    return balance;
    }
    
    public void applyMonthlyfee()
    { double applyMonthlyfee = balance - 150.55;
    }
    public double getMonthlyfee(double Monthlyfee)
    { double getmonthlyfee = -150.55;
        return getmonthlyfee;
    }
}
