public class circlearea {

		public static void main(String[] args)	{
		
		double radius = 8.2;
		
		double area = 3.14 * 8.2 * 8.2;
		
		System.out.println("the area is " + area);
		
		}
}